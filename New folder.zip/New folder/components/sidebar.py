import dash
import dash_bootstrap_components as dbc
from dash import html

def get_sidebar():
    links = []
    for page in sorted(dash.page_registry.values(), key=lambda p: p.get("order", 0)):
        links.append(
            dbc.NavLink(page["name"], href=page["path"], active="exact")
        )

    return html.Div(
        [
            html.H4("Service Dashboard", className="text-white"),
            html.Hr(),
            dbc.Nav(links, vertical=True, pills=True),
        ],
        style={
            "position": "fixed",
            "top": 0,
            "left": 0,
            "bottom": 0,
            "width": "16rem",
            "padding": "2rem 1rem",
            "background-color": "#343a40",
        },
    )
