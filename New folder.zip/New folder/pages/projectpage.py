import dash
from dash import html ,dcc,callback,Input, Output
from services.getproject import get_projects
from layout.project_grid import project_grid
import json

dash.register_page(__name__, path="/project",name="List Projects", order=3)

projects = get_projects()

layout = html.Div([
    dcc.Location(id="navigate"),
    html.H3("Projects"),
    project_grid(projects),
    
    html.Hr(),

    html.Pre(id="project-details")
])


@callback(

    Output("navigate", "href"),
    Input("projects-grid", "selectedRows"),
    prevent_initial_call=True
)
# def load_project_details(selected_rows):
#     if not selected_rows:
#         return "Select a project to view details"

#     project_no = selected_rows[0]["ProjectNo"]
#     details = get_project_details(project_no)
#     return json.dumps(details, indent=2)

def navigate_to_details(selected_rows):
    if not selected_rows:
        return dash.no_update

    project_no = selected_rows[0]["ProjectNo"]
    # return project_no

    return f"/project-details?projectNo={project_no}"

# forecast?proj_id={{project_no}}&modelVersion={VERSION}

