import dash
from dash import html, Input, Output
import dash_ag_grid as dag
import pandas as pd

dash.register_page(__name__, name="Service Cost", order=2)

df = pd.DataFrame({
    "Service Order": ["SO-1001", "SO-1002", "SO-1003"],
    "Technician Hours": [12, 8, 15],
    "Material Cost": [4500, 3200, 6100],
    "Total Cost": [8500, 6200, 11100],
})

layout = html.Div(
    [
        html.H2("Service Cost Overview"),
        dag.AgGrid(
            id="service-grid",
            rowData=df.to_dict("records"),
            columnDefs=[{"field": c} for c in df.columns],
            defaultColDef={"sortable": True, "filter": True},
        ),
        html.Div(id="selected-row"),
    ]
)

@dash.callback(
    Output("selected-row", "children"),
    Input("service-grid", "selectedRows"),
)
def show_selected(rows):
    if rows:
        return f"Selected Service Order: {rows[0]['Service Order']}"
    return "Select a row"
