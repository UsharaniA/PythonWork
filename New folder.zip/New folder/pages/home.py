import dash
import os
import pandas as pd
import dataiku
from dash import html, dcc, Output, Input
import dash_ag_grid as dag
import plotly.express as px
import dash_bootstrap_components as dbc
from dotenv import load_dotenv
import warnings, urllib3

# dash.register_page(__name__, path="/", name="Dataset Viewer", title="DV")
dash.register_page(__name__, path="/", name="Home", order=1)

warnings.simplefilter("ignore", urllib3.exceptions.InsecureRequestWarning)
load_dotenv()

DKU_DSS_URL = os.getenv("DKU_DSS_URL")
DKU_API_KEY = os.getenv("DKU_API_KEY")
PROJECT_KEY = os.getenv("DKU_PROJECT_KEY")

dataiku.set_remote_dss(DKU_DSS_URL, DKU_API_KEY, no_check_certificate=True)
dataiku.set_default_project_key(PROJECT_KEY)

dataset_list = ["tx_joined", "tx_group"]

def load_dataset(tablename, limit=100):
    return dataiku.Dataset(tablename).get_dataframe(limit=limit)

# -----------------------------
# Layout with Tabs
# -----------------------------
layout = dbc.Container([
    dbc.Row([dbc.Col(html.H1("Dataiku Dataset Viewer"), width=12)]),

    dbc.Row([
        dbc.Col([
            html.Label("Select Dataset:"),
            dcc.Dropdown(
                id="dataset-dropdown",
                options=[{"label": d, "value": d} for d in dataset_list],
                value=dataset_list[0]
            )
        ], width=4)
    ]),

    dbc.Row([
        dbc.Col(
            dbc.Tabs(
                [
                    dbc.Tab(label="Table", tab_id="tab-table"),
                    dbc.Tab(label="Charts", tab_id="tab-charts"),
                    dbc.Tab(label="Summary", tab_id="tab-summary"),
                ],
                id="tabs",
                active_tab="tab-table"
            ),
            width=12
        )
    ]),

    dbc.Row([
        dbc.Col(html.Div(id="tab-content"), width=12)
    ])
], fluid=True)

# -----------------------------
# Callbacks
# -----------------------------
@dash.callback(
    Output("tab-content", "children"),
    Input("tabs", "active_tab"),
    Input("dataset-dropdown", "value")
)
def render_tab(active_tab, tablename):
    df = load_dataset(tablename)

    if active_tab == "tab-table":
        return dag.AgGrid(
            id="data-table",
            className="ag-theme-alpine-dark",
            columnDefs=[{"headerName": col, "field": col} for col in df.columns],
            rowData=df.to_dict("records"),
            defaultColDef={
                "sortable": True,
                "resizable": True,
                "filter": "agTextColumnFilter",
                "floatingFilter": True
            },
            dashGridOptions={"pagination": True, "paginationPageSize": 10}
        )

    elif active_tab == "tab-charts":
        if tablename == "tx_group":
            top5 = df.sort_values(by="count", ascending=False).head(5)
            fig = px.bar(
                top5,
                x="card_id",
                y="count",
                color="card_id",
                title=f"CardID Counts in {tablename}",
                template="plotly_dark"
            )
            fig.update_layout(xaxis=dict(tickangle=-45, categoryorder="total descending"))

            return dbc.Row([
                dbc.Col(dcc.Graph(id="dataset-graph", figure=fig), width=6),
                dbc.Col(dcc.Graph(id="purchase-amount-chart", figure={}), width=6)
            ])
        else:
            return html.P("Charts available only for tx_group dataset.")

    elif active_tab == "tab-summary":
        return html.Div([
            html.H4("Dataset Summary"),
            html.P(f"Rows: {df.shape[0]}, Columns: {df.shape[1]}"),
            html.Ul([html.Li(col) for col in df.columns])
        ])

    return html.P("Select a tab.")

# -----------------------------
# Hover callback for purchase chart
# -----------------------------
@dash.callback(
    Output("purchase-amount-chart", "figure"),
    Input("dataset-graph", "hoverData"),
    Input("dataset-dropdown", "value")
)
def update_purchase_chart(hoverData, tablename):
    if not hoverData or "points" not in hoverData or not hoverData["points"]:

        return {}

    if tablename != "tx_group":
        return {}

    df = load_dataset(tablename)

    if "purchase_amount_sum" not in df.columns:
        return {}

    card_id = hoverData["points"][0]["x"]
    sum_df = df[df["card_id"] == card_id].groupby("card_id")["purchase_amount_sum"].sum().reset_index()

    return px.bar(
        sum_df,
        x="card_id",
        y="purchase_amount_sum",
        title=f"Total Purchase Amount for Card ID: {card_id}",
        color="card_id",
        template="plotly_dark"
    )

# Pydantic 
#excel validation 
#modularise 
# Dataiku sync with local 


