# #  %%
# # import sys
# # from pathlib import Path
# # Project_root=Path(__file__).parent.parent
# # sys.path.insert(0,str(Project_root))






# # %%
# import dash
# from dash import html
# from services.data_parser import scenario_to_dataframe
# import os
# from dotenv import load_dotenv
# import requests

# import urllib3
# urllib3.disable_warnings()  # suppress warnings
# # print(sys.path[0])
# # print(Project_root)
# # print("python executable",sys.executable)


# # ENV_KEYS=["API_ENDPOINT","ACCESS_TOKEN"]
# # for key in ENV_KEYS:
# #     os.environ.pop(key,None)
 
# # load_dotenv(dotenv_path=Project_root/".env")
# #  %%

# dash.register_page(__name__, path="/scenario",name="Scenario Actuals", order=4)

# # %%
# load_dotenv()

# # config = dataiku.get_custom_variables()

# # %%
# api_endpoint = os.getenv("API_ENDPOINT")

# access_token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IlBjWDk4R1g0MjBUMVg2c0JEa3poUW1xZ3dNVSIsImtpZCI6IlBjWDk4R1g0MjBUMVg2c0JEa3poUW1xZ3dNVSJ9.eyJhdWQiOiJhcGk6Ly9TZXJ2aWNlQ29zdE1vZGVsLmRldiIsImlzcyI6Imh0dHBzOi8vc3RzLndpbmRvd3MubmV0L2MwNzAxOTQwLTdiM2YtNDExNi1hNTlmLTE1OTA3OGJjM2M2My8iLCJpYXQiOjE3NjgzNzY0NDYsIm5iZiI6MTc2ODM3NjQ0NiwiZXhwIjoxNzY4MzgwNDIzLCJhY3IiOiIxIiwiYWlvIjoiQVpRQWEvOGFBQUFBTndyaXdPclBocjZwN3BSaG5kOGVhWEZiRExvbUg1Zk16UmFpYUF5NXBUKzBhNllYcXhWNmo3aFgrWWgvQTFuNVc1ZVFQRXJmazBkTVBZRTM1MkVpWmQ3TENtYWhTOURiQVBrUkoyemdIQWF1R2ZqYTJ0QVJQc3h4RmVxakxiaDRhZzA1cTdiQVhtQkE0VWxGdzhtM2UvRmtXbUMvK3BEZ0VaZ2RlY1BZcElEY2o2TkQ5S3luQVNwc1ZQRnM2ZUQrIiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJhcHBpZCI6ImVkOTQ5NjA0LWU0ZDMtNDVkYy1hODZkLWZmZWZhMjdhY2ZiYiIsImFwcGlkYWNyIjoiMSIsImZhbWlseV9uYW1lIjoiQXJ1bmFjaGFsYW0iLCJnaXZlbl9uYW1lIjoiVXNoYXJhbmkiLCJpcGFkZHIiOiI0NS4xMTkuMjguNDEiLCJuYW1lIjoiVXNoYXJhbmkgQXJ1bmFjaGFsYW0iLCJvaWQiOiIwMGIyZjVhMi0wOWYxLTQ1ODYtYmJjYy0wNWI4MTY5ODE4NmUiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtMTY1OTAwNDUwMy0yMDc3ODA2MjA5LTY4MjAwMzMzMC00NDY1MzYzIiwicmgiOiIxLkFSRUFRQmx3d0Q5N0ZrR2xueFdRZUx3OFk4WVFQbEJjT2Q5TWxGYkFwZU5kX3lZUkFDY1JBQS4iLCJyb2xlcyI6WyJzaGlueWFwcCJdLCJzY3AiOiJBUEkuQWxsIiwic2lkIjoiMDAxMTQ1ZmEtNTAyNi1mYjBiLTgzNGQtOTdlZjUzMzk5MzVhIiwic3ViIjoielVWLVhBZWlnRGVuNzI2OEdsbzFpWEFXZlVaN1dpOUFBc2hBQVlaeGNHUSIsInRpZCI6ImMwNzAxOTQwLTdiM2YtNDExNi1hNTlmLTE1OTA3OGJjM2M2MyIsInVuaXF1ZV9uYW1lIjoiVUhSTklAdmVzdGFzLmNvbSIsInVwbiI6IlVIUk5JQHZlc3Rhcy5jb20iLCJ1dGkiOiJwdzhEbEo2SnZrbXMxWWIzYVpjUEFBIiwidmVyIjoiMS4wIiwieG1zX2Z0ZCI6IktMbVhPSEJ6NjFtLU9wM0FBZlhxaGpkZzVkMGdKYVJJN1NIRHpIamhvTk1CYzNkbFpHVnVZeTFrYzIxeiJ9.OB7XublHNVLFf60HDdl1lnHz6awOUU8uYiSIMnVp2bpsrMua_OmKJG_xvHTvgmdeTRCyNzqB3rXf07ILc1mmZd7EUbqoA64SnKxcN-N2CaqQO_MP2mFGC1DhPaCHi7SsVrkBumm4zljOaDb7g1kvKMOcDxmsgpGhpWSWC56PB3sW4UZ_BXPGX9nhEWSncaAVI--j16CBXyvb_gr1IcORbvKOie_FfOKCf04mdyAbGdqpzCXgU-9gAvl-8L1iR_UYWCWRqG2hUWfosMvWKk3x3gpVEFqQW_U_zrkuEnm8e0uGz5WQKG5CSOIgKTwDiKmXdbffZF_VMryX3kIrn8slKQ"
# # %%

# headers = {
#     "Authorization": f"Bearer {access_token}",
#     "Content-Type": "application/json"
# }

# # %%
# response = requests.get(api_endpoint, headers=headers,verify=False)

# print(response.status_code)
# data = response.json()
# #  %%
# df = scenario_to_dataframe(data)
# df

# layout = html.Div(
#     [
#         html.H2("Scenario Actuals"),
#         html.Pre(df.to_string())
#     ]
# )
# # %%
