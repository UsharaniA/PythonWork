import dash
from dash import html, dcc, callback, Input, Output
import dash_ag_grid as dag
from services.getproject import get_forecast_details 
from services.data_parser import scenario_to_dataframe
 

dash.register_page(__name__, path="/project-details", order=4)

layout = html.Div([
    dcc.Location(id="url"),
    html.H3(id="html-head"),
    html.Pre(id="htmlid")

    # dag.AgGrid(
    #     id="details-grid",
    #     columnDefs=[],
    #     rowData=[],
    #     style={"height": "400px"}
    # )
])

@callback(
    # Output("details-grid", "rowData"),
    # Output("details-grid", "columnDefs"),
    Output("html-head", "children"),
    Output("htmlid", "children"),
    Input("url", "search")
)
def load_project_details(search):
    if not search:
        return [], []

    project_no = search.split("=")[1]

    api_data = get_forecast_details(project_no)

    # column_defs = [
    #     {"headerName": key, "field": key}
    #     for key in api_data[0].keys()
    # # ]
    df=scenario_to_dataframe(api_data)

    return f"Project Details-{project_no}", df.to_string()

