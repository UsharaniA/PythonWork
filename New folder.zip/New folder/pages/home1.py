# import dash
# from dash import html

# dash.register_page(__name__, path="/", name="Home", order=1)

# layout = html.Div(
#     [
#         html.H2("Welcome 👋"),
#         html.P("Sidebar is generated from registered pages."),
#     ]
# )
