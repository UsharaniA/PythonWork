BASE_URL = "https://dev.api.vestas.net/vps/scmapi"
VERSION="3.0.13"

PROJECTS_API = f"{BASE_URL}/backlog/projects?modelVersion={VERSION}"
FORECAST_API = f"{BASE_URL}/backlog/forecast?proj_id={{project_no}}&modelVersion={VERSION}"

# https://dev.api.vestas.net/vps/scmapi/backlog/projects?modelVersion=3.0.13

# API_ENDPOINT="https://dev.api.vestas.net/vps/scmapi/backlog/forecast?proj_id=SC-011313&modelVersion=3.0.13"