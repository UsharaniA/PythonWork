#  %%
import sys
from pathlib import Path
Project_root=Path(__file__).parent.parent
sys.path.insert(0,str(Project_root))



# %%
import dash
from dash import html
from services.data_parser import scenario_to_dataframe
import os
from dotenv import load_dotenv
import requests

import urllib3
urllib3.disable_warnings()  # suppress warnings
print(sys.path[0])
print("python executable",sys.executable)
# load_dotenv(dotenv_path=Project_root/".env")
#  %%
# dash.register_page(
#     __name__,
#     path="/scenario",
#     name="Scenario Actuals"
# )

# %%
load_dotenv()

# config = dataiku.get_custom_variables()

# %%
# api_endpoint = os.getenv("API_ENDPOINT")

# access_token = os.getenv("ACCESS_TOKEN")
api_endpoint="https://dev.api.vestas.net/vps/scmapi/backlog/projects?modelVersion=3.0.13"
access_token="eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IlBjWDk4R1g0MjBUMVg2c0JEa3poUW1xZ3dNVSIsImtpZCI6IlBjWDk4R1g0MjBUMVg2c0JEa3poUW1xZ3dNVSJ9.eyJhdWQiOiJhcGk6Ly9TZXJ2aWNlQ29zdE1vZGVsLmRldiIsImlzcyI6Imh0dHBzOi8vc3RzLndpbmRvd3MubmV0L2MwNzAxOTQwLTdiM2YtNDExNi1hNTlmLTE1OTA3OGJjM2M2My8iLCJpYXQiOjE3NjgzODY3MDUsIm5iZiI6MTc2ODM4NjcwNSwiZXhwIjoxNzY4MzkxNTg1LCJhY3IiOiIxIiwiYWlvIjoiQVpRQWEvOGFBQUFBZzdZNFc0aDBWUzE2cXl2RFhvbnFyQlc1YnNHMFdSYXk4Szk4d2ZtbGwweWlxZzZkMkovQkg3VTZ1TnljdWNMK29tL1QxYnVZV0VTb1ZjcElvSWpDUUU1bm1KWUp2TFBKTTJNYW5YZFM0Z1NYN0NMUUV1RmxvcjNvd0lVTktLQzhCUXY1L1cxSGN6WDdTUmRVUGxCc01tbkwwanRLeC9WRVRobEhra3Z6SEh2SEpZcVVsWkdPTlIrdHdKSXdwWG9EIiwiYW1yIjpbInB3ZCIsIm1mYSJdLCJhcHBpZCI6ImVkOTQ5NjA0LWU0ZDMtNDVkYy1hODZkLWZmZWZhMjdhY2ZiYiIsImFwcGlkYWNyIjoiMSIsImZhbWlseV9uYW1lIjoiQXJ1bmFjaGFsYW0iLCJnaXZlbl9uYW1lIjoiVXNoYXJhbmkiLCJpcGFkZHIiOiI0NS4xMTkuMjguNDEiLCJuYW1lIjoiVXNoYXJhbmkgQXJ1bmFjaGFsYW0iLCJvaWQiOiIwMGIyZjVhMi0wOWYxLTQ1ODYtYmJjYy0wNWI4MTY5ODE4NmUiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtMTY1OTAwNDUwMy0yMDc3ODA2MjA5LTY4MjAwMzMzMC00NDY1MzYzIiwicmgiOiIxLkFSRUFRQmx3d0Q5N0ZrR2xueFdRZUx3OFk4WVFQbEJjT2Q5TWxGYkFwZU5kX3lZUkFDY1JBQS4iLCJyb2xlcyI6WyJzaGlueWFwcCJdLCJzY3AiOiJBUEkuQWxsIiwic2lkIjoiMDAxMTQ1ZmEtNTAyNi1mYjBiLTgzNGQtOTdlZjUzMzk5MzVhIiwic3ViIjoielVWLVhBZWlnRGVuNzI2OEdsbzFpWEFXZlVaN1dpOUFBc2hBQVlaeGNHUSIsInRpZCI6ImMwNzAxOTQwLTdiM2YtNDExNi1hNTlmLTE1OTA3OGJjM2M2MyIsInVuaXF1ZV9uYW1lIjoiVUhSTklAdmVzdGFzLmNvbSIsInVwbiI6IlVIUk5JQHZlc3Rhcy5jb20iLCJ1dGkiOiJ5Z0ZMamFVdHFFaVNzLXoxLXVBMEFBIiwidmVyIjoiMS4wIiwieG1zX2Z0ZCI6IjRmU2JsTi1rOURrSWl0SVByY0Q5S19CWTZaV0YzUnhOb3pIYjJwLXRrN1lCWlhWeWIzQmxkMlZ6ZEMxa2MyMXoifQ.WLVeWTjk5tRS2nkfeFfdXHHWGYAqXyuGYOXDnTEUWPe4NtdJXWdn8PsELDTcjLXVbROQkauB1vEKw43h5dC5ivhhIjQeC0vK1cQkfc5fdItFrd2hUOEeY2V6ByxF7UMpa4qZlkg40_TkHRuPPZsnO8QUX1M8wcxMxjtB2ErSPsr_5Ac4RCPlfd4KZP7tA7tpRfatcUCZvHB1vVRaApVjEo_o_tX0ak8163EW0Tz-VzzuUqc-CJ8jDaGKHZ_2iA1R6ZX2KGEsNVIc2MmK7tQ7niCWoL2iq82rX-DNi4b6dwN6rAVsZMtcJNnsbUx9ZA4fc1n82zIq-gpjgB25ZwRacg"



# print (access_token)
# %%

headers = {
    "Authorization": f"Bearer {access_token}",
    "Content-Type": "application/json"
}

# %%
response = requests.get(api_endpoint, headers=headers,verify=False)

print(response.status_code)
data = response.json()
#  %%
df = scenario_to_dataframe(data)

print(df)

# layout = html.Div(
#     [
#         html.H2("Scenario Actuals"),
#         html.Pre(df.head().to_string())
#     ]
# )