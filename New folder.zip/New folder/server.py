from app import app
from layout.main_layout import serve_layout

app.layout = serve_layout()

if __name__ == "__main__":
    app.run(
        host="127.0.0.1",
        port=8051,
        debug=True,
        use_reloader=True 
    )