from dash import html
import dash
from components.sidebar import get_sidebar

def serve_layout():
    return html.Div(
        [
            get_sidebar(),
            html.Div(
                dash.page_container,
                style={"margin-left": "18rem", "padding": "2rem"},
            ),
        ]
    )
