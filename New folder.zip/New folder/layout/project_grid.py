import dash_ag_grid as dag

def project_grid(projects):
    return dag.AgGrid(
        id="projects-grid",
        columnDefs=[
            {"headerName": "Project No", "field": "ProjectNo"},
            {"headerName": "Project Name", "field": "ProjectDescription"},
            {"headerName": "Company", "field": "CompanyName"},
            {"headerName": "Currency", "field": "CurrencyCode"},
            {"headerName": "WTGs", "field": "n_wtgs"},
        ],
        rowData=projects,
        dashGridOptions={
                    "rowSelection": "single",
                    "pagination": True,
                    'checkboxes': True ,
                    'enableClickSelection': True,
                    "paginationPageSize": 10,
                    "domLayout": "autoHeight"
                },
        style={"height": "400px", "width": "100%"}
    )