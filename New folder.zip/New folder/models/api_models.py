from pydantic import BaseModel
from typing import List, Dict


class TimeModel(BaseModel):
  cal_year: List[int]
  cal_month: List[int]


class RawMetric(BaseModel):
 id: str
 value: List[float]
 labels: Dict[str, List[str]]


class ForecastActuals(BaseModel):
  time: TimeModel
  raw: List[RawMetric]


class ScenarioActual(BaseModel):
  turbine_grp_label: str
  cim_factor: float
  monthly_actuals_end_date: str
  forecastActuals: ForecastActuals


class ApiResponse(BaseModel):
  scenarioActuals: List[ScenarioActual]
  success: bool
