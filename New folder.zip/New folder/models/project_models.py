from pydantic import BaseModel
from typing import List

class Project(BaseModel):
    ProjectNo: str
    ProjectDescription: str
    CompanyName: str
    CurrencyCode: str
    n_wtgs: int

class ProjectResponse(BaseModel):
    projects: List[Project]