import pandas as pd
from models.api_models import ApiResponse


def scenario_to_dataframe(data: dict) -> pd.DataFrame:
  

    response = ApiResponse(**data) 
    scenario = response.scenarioActuals[0]
    forecast = scenario.forecastActuals

    rows = []

    years = forecast.time.cal_year
    months = forecast.time.cal_month

    for metric in forecast.raw:
        for year, month, value in zip(years, months, metric.value):
            rows.append({
                "id": metric.id,
                "value": value,
                "cal_year": year,
                "cal_month": month
            })

    return pd.DataFrame(rows)